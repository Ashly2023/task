<?php
include("connection.php");
if(isset($_POST['submit']))
{   
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$sql = "INSERT INTO reg (name,email,phone)
     VALUES ('$name','$email','$phone')";
   mysqli_query($mysqli,$sql);
   header("Location:view.php");
 }
?> 
<!DOCTYPE html>
<html>
    <title></title>
    <head>
    <script type="text/javascript">
        function fun() {
    if (document.form1.name.value == "") {
        alert("Enter a name");
        document.form1.name.focus();
        return false;
    }
    if (!/^[a-zA-Z]*$/g.test(document.form1.name.value)) {
        alert("Invalid characters");
        document.form1.name.focus();
        return false;
    }

 if (document.form1.email.value == "") {
        alert("Enter a email");
        document.form1.email.focus();
        return false;
    }
    if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/.test(document.form1.email.value)) {
        alert("Invalid email");
        document.form1.email.focus();
        return false;
    }
    if (document.form1.phone.value == "") {
        alert("Enter a number");
        document.form1.phone.focus();
        return false;
    }
    if (!/^[0-9]*$/.test(document.form1.phone.value)) {
        alert("Invalid number");
        document.form1.phone.focus();
        return false;
    }
    
}
</script>
</head>
<body>
 <form name="form1" method="post" action="" onsubmit="return fun()">   
          <h2>Form Details</h2>
         Name:<input type="text" name="name"><br><br>
         Email:<input type="text" name="email"><br><br>
         Phone:<input type="text" name="phone"><br><br>
        <input type="submit" name="submit" value="submit">
          </form>
</body>
</html>
