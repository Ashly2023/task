<?php
$a=1;
$b=3;
$c=$a+$b;
echo $c;
?>