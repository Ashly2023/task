<!DOCTYPE HTML>  
<html>
  <title></title>
  <head>
    
</head>
<body>

<table border ="1" cellspacing="0" cellpadding="10">
<h2>Form Details</h2>
  <tr>
    <th>S.N</th>
    <th>First Name</th>
    <th>Last Name</th>
    <th>Email</th>
    
    </tr>
<?php
include("connection.php");
$result="select * from reg";
$query=mysqli_query($mysqli,$result);
while($row=mysqli_fetch_assoc($query)){
  ?>
 <tr>
  <td><?php echo $row['id']; ?> </td>
   <td><?php echo $row['name']; ?> </td>
   <td><?php echo $row['email']; ?> </td>
   <td><?php echo $row['phone']; ?> </td>
  <?php
}
  ?>
 <tr>

  </table>
</body>
</html>